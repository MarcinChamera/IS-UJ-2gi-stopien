/*
 * InitialDataGenerator.cpp
 *
 *  Created on: 20 paź 2021
 *      Author: oramus
 */

#include "InitialDataGenerator.h"

