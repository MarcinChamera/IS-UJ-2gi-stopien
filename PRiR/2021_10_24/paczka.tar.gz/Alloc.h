/*
 * Alloc.h
 *
 *  Created on: 20 paź 2021
 *      Author: oramus
 */

#ifndef ALLOC_H_
#define ALLOC_H_

double **tableAlloc( int size );

#endif /* ALLOC_H_ */
